﻿using System;

namespace mancini.nicola._3H.giorno
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("programma di Nicola Mancini");


            int anno;
            string strAnno;
            int giorno;
            string strGiorno;

            Console.WriteLine("inserisci anno");
            strAnno = Console.ReadLine();
            anno = Convert.ToInt32(strAnno);

            Console.WriteLine("inserisci giorni");
            strGiorno = Console.ReadLine();
            giorno = Convert.ToInt32(strGiorno);


           
            Console.WriteLine();


            if (anno % 400 == 0 || (anno % 4 == 0 && (anno % 100 == 0)))
            {
                if(giorno<=31)
                {
                    Console.WriteLine("la data è...");
                    Console.WriteLine(giorno);
                    Console.WriteLine("gennaio");
                    Console.WriteLine(anno);

                }
                else
                {
                    if(giorno<=60)
                    {
                        Console.WriteLine("la data è...");
                        Console.WriteLine(giorno - 31);
                        Console.WriteLine("febbraio");
                        Console.WriteLine(anno);
                    }
                    else
                    {
                        if(giorno<=91)
                        {
                            Console.WriteLine("la data è...");
                            Console.WriteLine(giorno - 60);
                            Console.WriteLine("marzo");
                            Console.WriteLine(anno);
                        }
                        else
                        {
                            if(giorno<=121)
                            {
                                Console.WriteLine("la data è...");
                                Console.WriteLine(giorno - 91);
                                Console.WriteLine("aprile");
                                Console.WriteLine(anno);
                            }
                            else
                            {
                                if(giorno<=152)
                                 {
                                    Console.WriteLine("la data è...");
                                    Console.WriteLine(giorno - 121);
                                    Console.WriteLine("maggio");
                                    Console.WriteLine(anno);
                                }
                                else
                                {
                                    if(giorno<=182)
                                    {
                                        Console.WriteLine("la data è...");
                                        Console.WriteLine(giorno - 152);
                                        Console.WriteLine("giugno");
                                        Console.WriteLine(anno);
                                    }
                                    else
                                    {
                                        if(giorno<=213)
                                         {
                                            Console.WriteLine("la data è...");
                                            Console.WriteLine(giorno - 182);
                                            Console.WriteLine("luglio");
                                            Console.WriteLine(anno);
                                        }
                                        else
                                        {
                                            if(giorno<=244)
                                             {
                                                Console.WriteLine("la data è...");
                                                Console.WriteLine(giorno - 213);
                                                Console.WriteLine("agosto");
                                                Console.WriteLine(anno);
                                            }
                                            else
                                            {
                                                if(giorno<=274)
                                                 {
                                                    Console.WriteLine("la data è...");
                                                    Console.WriteLine(giorno - 244);
                                                    Console.WriteLine("settembre");
                                                    Console.WriteLine(anno);
                                                }
                                                else
                                                {
                                                    if(giorno<=305)
                                                     {
                                                        Console.WriteLine("la data è...");
                                                        Console.WriteLine(giorno - 274);
                                                        Console.WriteLine("ottobre");
                                                        Console.WriteLine(anno);
                                                    }
                                                    else
                                                    {
                                                        if(giorno<=335)
                                                         {
                                                            Console.WriteLine("la data è...");
                                                            Console.WriteLine(giorno - 305);
                                                            Console.WriteLine("novembre");
                                                            Console.WriteLine(anno);
                                                        }
                                                        else
                                                        {
                                                            if(giorno<=366)
                                                             {
                                                                Console.WriteLine("la data è...");
                                                                Console.WriteLine(giorno - 335);
                                                                Console.WriteLine("dicembre");
                                                                Console.WriteLine(anno);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                Console.WriteLine("e se l'anno non fosse bisestile:"); }
            }




           
            

            if(giorno<=31)
            {
                Console.WriteLine("la data è...");
                Console.WriteLine(giorno );
                Console.WriteLine("gennaio");
                Console.WriteLine(anno);
                
            }
            else 
            {

                if(giorno<=59)
                {

                    Console.WriteLine("la data è...");
                    Console.WriteLine(giorno-31);
                    Console.WriteLine("febbraio");
                    Console.WriteLine(anno);


                }
                else
                {
                    if(giorno<=90)
                    {
                        Console.WriteLine("la data è...");
                        Console.WriteLine(giorno - 59);
                        Console.WriteLine("marzo");
                        Console.WriteLine(anno);
                    }
                    else
                    {
                        if(giorno<=120)
                        {
                            Console.WriteLine("la data è...");
                            Console.WriteLine(giorno - 90);
                            Console.WriteLine("aprile");
                            Console.WriteLine(anno);


                        }
                        else
                        {
                            if(giorno<=151)
                            {
                                Console.WriteLine("la data è...");
                                Console.WriteLine(giorno - 120);
                                Console.WriteLine("maggio");
                                Console.WriteLine(anno);
                            }
                            else
                            {
                                if(giorno<=181)
                                {
                                    Console.WriteLine("la data è...");
                                    Console.WriteLine(giorno - 151);
                                    Console.WriteLine("giugno");
                                    Console.WriteLine(anno);
                                }
                                else
                                {
                                    if(giorno<=212)
                                    {
                                        Console.WriteLine("la data è...");
                                        Console.WriteLine(giorno - 181);
                                        Console.WriteLine("luglio");
                                        Console.WriteLine(anno);
                                    }
                                    else
                                    {
                                        if(giorno<=243)
                                        {
                                            Console.WriteLine("la data è...");
                                            Console.WriteLine(giorno - 212);
                                            Console.WriteLine("agosto");
                                            Console.WriteLine(anno);
                                        }
                                        else
                                        {
                                            if(giorno<=273)
                                            {
                                                Console.WriteLine("la data è...");
                                                Console.WriteLine(giorno - 243);
                                                Console.WriteLine("settembre");
                                                Console.WriteLine(anno);
                                            }
                                            else
                                            {
                                                if(giorno<=304)
                                                {
                                                    Console.WriteLine("la data è...");
                                                    Console.WriteLine(giorno - 273);
                                                    Console.WriteLine("ottobre");
                                                    Console.WriteLine(anno);
                                                }
                                                else
                                                {
                                                    if(giorno<=334)
                                                    {
                                                        Console.WriteLine("la data è...");
                                                        Console.WriteLine(giorno - 304);
                                                        Console.WriteLine("novembre");
                                                        Console.WriteLine(anno);
                                                    }
                                                    else
                                                    {
                                                        if(giorno<=365)
                                                        {
                                                            Console.WriteLine("la data è...");
                                                            Console.WriteLine(giorno - 334);
                                                            Console.WriteLine("dicembre");
                                                            Console.WriteLine(anno);
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                    }
                                }
                            }
                        }
                    }
                }
            }
              
        }
    }
}
